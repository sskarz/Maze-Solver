package hw05;

import java.util.ArrayList;

/**
 * Class to solve the maze recursively.
 * 
 * @author <YOUR INFORMATION GOES HERE>
 *
 * YOU MAY ONLY CHANGE THE METHOD THAT IS INDICATED IN THIS CLASS.
 */

public class MazeSolver {

	
	/**
	 * Constructor is private since there is no need to instantiate this class as it only contains
	 * static methods.
	 */
	private MazeSolver() {}

	/**
	 * Public method to solve a maze using recursion.  This method creates two empty ArrayLists
	 * that the recursive helper method will need to solve the given maze.
	 * 
	 * @param maze The {@code Maze} object we want to solve.
	 */
	public static void solve(Maze maze) {
		//ArrayList to keep track of which coordinates are on the path from start to end.
		ArrayList<Coordinate> path = new ArrayList<>();

		//ArrayList to keep track of which coordinates you have already been to.
		ArrayList<Coordinate> history = new ArrayList<>();
		solve(maze, maze.getStart(), path, history);
	}

	/**
	 * The recursive helper method that YOU will implement.  This method will do all the work for
	 * solving the maze.  
	 * 
	 * @param maze	The {@code Maze} object to solve.
	 * 
	 * @param currentPos	The {@code Coordinate} object that keeps track of your current position in the maze.
	 * 
	 * @param path			The {@code ArrayList} of {@code Coordinate} objects that are currently on the path
	 * 						from the start of the maze to the end.  This ArrayList should only contain the 
	 * 						coordinates from start up to your current position, and eventually should contain
	 * 						all the coordinates from start to end.
	 * 
	 * @param history		The {@code ArrayList} of {@code Coordinate} objects that you have already visited.
	 * 						This helps you to keep track of where you have been so you do not check the same
	 * 						position more than once.
	 */
	private static void solve(Maze maze, Coordinate currentPos, ArrayList<Coordinate> path, ArrayList<Coordinate> history) {
		//THIS IS THE METHOD THAT YOU MUST IMPLEMENT.
		//YOU MAY NOT CHANGE THE METHOD HEADER
		Coordinate north = new Coordinate(currentPos.getRowIndex() - 1, currentPos.getColIndex());
		Coordinate east = new Coordinate(currentPos.getRowIndex(), currentPos.getColIndex() + 1);
		Coordinate south = new Coordinate(currentPos.getRowIndex() + 1, currentPos.getColIndex());
		Coordinate west = new Coordinate(currentPos.getRowIndex(), currentPos.getColIndex() - 1);
		
		boolean northFailed = false;
		boolean eastFailed = false;
		boolean southFailed = false;
		boolean westFailed = false;
		
		history.add(currentPos);
		path.add(currentPos);
		
		if (maze.getMazeValue(currentPos.getRowIndex(), currentPos.getColIndex()) == 'E') {
			printResult(maze, path);
			return;
		}
		
		for (int i = 1; i <= 8; i++) {
			// check for north
			if (i == 1) { // i == 1 is north
				if (currentPos.getRowIndex() == 0) { // check if row = 0
					continue;
				} else if (history.contains(north)) { // check if history has north
					continue;
				} else if (maze.getMazeValue(currentPos.getRowIndex() - 1, currentPos.getColIndex()) == '+') {
					northFailed = true;
					continue;
				} else {
					solve(maze, north, path, history);
				}
			}
			
			if (i == 2) { // i == 2 is east
				if (history.contains(east)) { // check if history has north
					continue;
				} else if (maze.getMazeValue(currentPos.getRowIndex(), currentPos.getColIndex() + 1) == '+') {
					eastFailed = true;
					continue;
				} else {
					solve(maze, east, path, history);
				}
			}
			
			if (i == 3) { // i == 3 is south
				if (currentPos.getRowIndex() == maze.getNumRows() - 1) { // check if row = the last row
					continue;
				} else if (history.contains(south)) { // check if history has north
					continue;
				} else if (maze.getMazeValue(currentPos.getRowIndex() + 1, currentPos.getColIndex()) == '+') {
					southFailed = true;
					continue;
				} else {
					solve(maze, south, path, history);
				}
			}
			
			if (i == 4) { // i == 4 is west
				if (history.contains(west)) { // check if history has west
					continue;
				} else if (maze.getMazeValue(currentPos.getRowIndex(), currentPos.getColIndex() - 1) == '+') {
					westFailed = true;
					continue;
				} else {
					solve(maze, west, path, history);
				}
			}
			
			// ------------------------------------------------------------------------------------------------------------
			// DITCH CASES
			if (i == 5) { // north ditch
				if (history.contains(north) && eastFailed && southFailed && westFailed) {
					for (int a = 0; a < path.size(); a++) {
						if (path.get(a).equals(north)) {
							path.remove(a);
							break;
						}
					}
					solve(maze, north, path, history);
				}
			}
			
			if (i == 6) { // east ditch
				if (history.contains(east) && northFailed && southFailed && westFailed) {
					for (int b = 0; b < path.size(); b++) {
						if (path.get(b).equals(east)) {
							path.remove(b);
							break;
						}
					}
					solve(maze, east, path, history);
				}
			}
			
			if (i == 7) { // south ditch
				if (history.contains(south) && northFailed && eastFailed && westFailed) {
					for (int c = 0; c < path.size(); c++) {
						if (path.get(c).equals(south)) {
							path.remove(c);
							break;
						}
					}
					solve(maze, south, path, history);
				}
			}
			
			if (i == 8) { // west ditch
				if (history.contains(west) && northFailed && southFailed && eastFailed) {
					for (int d = 0; d < path.size(); d++) {
						if (path.get(d).equals(west)) {
							path.remove(d);
							break;
						}
					}
					solve(maze, west, path, history);
				}
			}
		}
	}

	/**
	 * Private method to print the final results once a solution has been found.
	 * 
	 * @param maze	A {@code Maze} object that we wish to display.
	 * @param path  An ArrayList of {@code Coordinate} objects that are on the path from the start
	 *              of the maze to the end.
	 */
	private static void printResult(Maze maze, ArrayList<Coordinate> path) {

		for (int i = 0 ; i < maze.getNumRows() ; i++) {
			for (int j = 0 ; j < maze.getNumCols(); j++) {
				Coordinate current = new Coordinate(i, j);
				
				if (current.equals(maze.getStart())) {
					System.out.print("S");
				}
				else {
					char ch = (path.contains(current) ? '*' : maze.getMazeValue(i, j));
					System.out.print(ch);
				}
			}
			System.out.println();
		}
		
		System.out.println("\nPATH:");
		
		for (int i = 1 ; i <= path.size() ; i++) {
			
			if (i == path.size()) {
				System.out.print(path.get(i - 1));
			}
			else {
				System.out.print(path.get(i - 1) + ", ");
			}
			
			
			if (i % 10 == 0)  {
				System.out.println();
			}
		}
		System.out.println();
		System.out.println();
	}
}